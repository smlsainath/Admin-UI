import Admin from './components/Admin'
import './App.css'

const App = () => <Admin />
export default App
