import {Component} from 'react'

import Header from '../Header'
import Search from '../Search'
import Sample from '../Sample'
import './index.css'

const apiUrl =
  'https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json'

class Admin extends Component {
  state = {
    adminData: [],
    searchInput: '',
  }

  componentDidMount() {
    this.getAdminData()
  }

  enterSearchInput = () => {
    this.getAdminData()
  }

  changeSearchInput = searchInput => {
    this.setState({searchInput})
  }

  setAdminData = fetchedData => {
    this.setState({
      adminData: fetchedData.map(eachAdminData => ({
        id: eachAdminData.id,
        name: eachAdminData.name,
        email: eachAdminData.email,
        role: eachAdminData.role,
      })),
    })
  }

  getAdminData = async () => {
    const response = await fetch(apiUrl)
    const fetchedData = await response.json()
    this.setAdminData(fetchedData, false)
  }

  renderAdminDataList = () => {
    const {adminData, searchInput} = this.state

    return (
      <div>
        <Search
          searchInput={searchInput}
          changeSearchInput={this.changeSearchInput}
          enterSearchInput={this.enterSearchInput}
        />
         <Header /> 
        
      </div>
    )
  }

  render() {
    return <div className="app-container">{this.renderAdminDataList()}</div>
  }
}

export default Admin
